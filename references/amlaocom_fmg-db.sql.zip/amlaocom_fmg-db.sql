-- phpMyAdmin SQL Dump
-- version 4.2.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 25, 2015 at 06:19 PM
-- Server version: 5.6.21
-- PHP Version: 5.5.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `amlaocom_fmg-db`
--
CREATE DATABASE IF NOT EXISTS `amlaocom_fmg-db` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `amlaocom_fmg-db`;

-- --------------------------------------------------------

--
-- Table structure for table `application_log`
--

CREATE TABLE IF NOT EXISTS `application_log` (
`id` int(11) NOT NULL,
  `log_type` varchar(145) DEFAULT NULL,
  `detail` varchar(45) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `company_profile`
--

CREATE TABLE IF NOT EXISTS `company_profile` (
`id` int(11) NOT NULL,
  `company_name` varchar(145) DEFAULT NULL,
  `logo` varchar(45) DEFAULT NULL,
  `address` varchar(245) DEFAULT NULL,
  `telephone` varchar(45) DEFAULT NULL,
  `fax` varchar(45) DEFAULT NULL,
  `mobile` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `company_profile`
--

INSERT INTO `company_profile` (`id`, `company_name`, `logo`, `address`, `telephone`, `fax`, `mobile`, `email`) VALUES
(1, 'IT Pedia Sole.,Ltd', NULL, 'Phonetong Savath, Vientiane, Laos', '+856 20 5999 8848', NULL, '+856 20 5999 8848', 'info@itpedia.la');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
`id` int(11) NOT NULL,
  `company_name` varchar(145) DEFAULT NULL,
  `contact_name` varchar(145) DEFAULT NULL COMMENT 'Manager, Director or owner name',
  `transaction_prefix` varchar(45) DEFAULT NULL COMMENT 'Code will use on transaction Ex: AA_, BB_, CC_',
  `address` varchar(145) DEFAULT NULL,
  `telephone` varchar(45) DEFAULT NULL,
  `fax` varchar(45) DEFAULT NULL,
  `mobile` varchar(45) DEFAULT NULL,
  `email` varchar(145) DEFAULT NULL,
  `send_location` varchar(245) DEFAULT NULL COMMENT 'Product send location or site',
  `dept_duration` int(11) DEFAULT NULL COMMENT 'Number of days for dept',
  `overpaid_charge_percentage` int(5) DEFAULT NULL COMMENT 'Charge (%) rate if customer not paid within dept_duration',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `remove` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `company_name`, `contact_name`, `transaction_prefix`, `address`, `telephone`, `fax`, `mobile`, `email`, `send_location`, `dept_duration`, `overpaid_charge_percentage`, `created_at`, `updated_at`, `remove`) VALUES
(1, 'IT Pedia Sole.,Ltd', 'Somwang', 'ITP_', 'Suite 408, Level 4, Press Club Building 59A Ly Thai To st, Hoan Kiem dist, Hanoi, VN', '+85620 59998848', '+85621251458', '+856 20 2222 6543', 'dsouksavatd@gmail.com', 'Skymediator', 45, 3, '2015-01-23 12:21:10', '2015-01-23 12:21:21', 0),
(2, 'ບໍລິສັດ ບ້ານລາວ ກໍ່ສ້າງ', 'ທ່ານ ເສນີ', 'BL_', 'ບ້ານ ບຶງຂະຫຍອງ, ເມືອງ ສີສັດຕະນາກ, ນະຄອນຫລວງວຽງຈັນ', '(856-21) 264 712 -5', '+85621251458', '020 55641699, 020 23315', 'silaphet.inthavong@miraclelao.com', 'ບ້ານຫ້ວຍຫົງ', 60, 3, '2015-01-25 10:36:31', '2015-01-25 10:42:05', 0),
(3, 'Skymediator', 'Greg', 'SKM_', 'ສີ່ແຍກໄຟແດງ ຫນ້າຄິວລົດ, ສະຫວັນນະເຂດ', '(856-21) 264 712 -5', '', '+85620 5448 8847', '', 'Pho tower', 0, 0, '2015-01-25 10:41:55', '2015-01-25 10:41:55', 0);

--
-- Triggers `customer`
--
DELIMITER //
CREATE TRIGGER `customer_BEFORE_INSERT` BEFORE INSERT ON `customer`
 FOR EACH ROW -- Edit trigger body code below this line. Do not edit lines above this one
BEGIN
SET new.remove = 0;
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `exchange_rate`
--

CREATE TABLE IF NOT EXISTS `exchange_rate` (
`id` int(11) NOT NULL,
  `USD` int(11) DEFAULT NULL,
  `THB` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `exchange_rate`
--

INSERT INTO `exchange_rate` (`id`, `USD`, `THB`, `created_at`, `updated_at`) VALUES
(1, 8000, 250, '2015-01-20 00:00:00', '2015-01-20 00:00:00'),
(2, 8000, 250, '2015-01-20 09:28:47', '2015-01-20 09:28:47'),
(3, 8000, 250, '2015-01-20 09:29:07', '2015-01-20 09:29:07'),
(4, 8000, 250, '2015-01-21 16:08:10', '2015-01-21 16:08:10');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
`id` int(11) NOT NULL,
  `title` varchar(145) DEFAULT NULL,
  `unit` varchar(45) DEFAULT NULL,
  `cement_kg` decimal(10,2) DEFAULT NULL,
  `sand_kg` decimal(10,2) DEFAULT NULL,
  `crashed_stone_kg` decimal(10,2) DEFAULT NULL,
  `water_litre` decimal(10,2) DEFAULT NULL,
  `admixture_1_cc` decimal(10,2) DEFAULT NULL,
  `admixture_2_cc` decimal(10,2) DEFAULT NULL,
  `admixture_3_cc` decimal(10,2) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `currency` varchar(45) DEFAULT NULL,
  `remark_note` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `remove` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=400 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `title`, `unit`, `cement_kg`, `sand_kg`, `crashed_stone_kg`, `water_litre`, `admixture_1_cc`, `admixture_2_cc`, `admixture_3_cc`, `price`, `currency`, `remark_note`, `created_at`, `updated_at`, `remove`) VALUES
(2, 'ສູດປູນ 10 Mpa', 'm3', '225.00', '772.00', '1234.00', '160.00', '520.00', '0.00', '0.00', '1900.00', 'thb', '', '2015-01-22 15:10:43', '2015-01-22 15:10:43', 0),
(3, 'ສູດປູນ 15 Mpa', 'm3', '250.00', '780.00', '1218.00', '155.00', '750.00', '0.00', '0.00', '2050.00', 'thb', '', '2015-01-23 12:26:23', '2015-01-23 12:26:23', 0),
(4, 'ສູດປູນ 20 Mpa', 'm3', '325.00', '764.00', '1202.00', '150.00', '900.00', '0.00', '0.00', '2150.00', 'thb', '', '2015-01-23 12:28:15', '2015-01-23 12:28:15', 0),
(5, 'ສູດປູນ 25 Mpa', 'm3', '350.00', '733.00', '1194.00', '150.00', '1068.00', '0.00', '0.00', '2200.00', 'thb', '', '2015-01-23 12:32:39', '2015-01-23 12:32:39', 0),
(6, 'ສູດປູນ 30 Mpa', 'm3', '375.00', '722.00', '1189.00', '148.00', '1144.00', '0.00', '0.00', '2350.00', 'thb', '', '2015-01-23 12:34:18', '2015-01-23 12:34:18', 0),
(7, 'ສູດປູນ 32 Mpa', 'm3', '400.00', '712.00', '1186.00', '145.00', '1240.00', '0.00', '0.00', '2400.00', 'thb', '', '2015-01-23 12:34:57', '2015-01-23 12:34:57', 0),
(8, 'ສູດປູນ 35 Mpa', 'm3', '425.00', '702.00', '1180.00', '145.00', '1336.00', '0.00', '0.00', '2450.00', 'thb', '', '2015-01-23 12:35:34', '2015-01-23 12:35:34', 0),
(9, 'ສູດປູນ 40 Mpa', 'm3', '460.00', '690.00', '1120.00', '169.00', '460.00', '3680.00', '0.00', '2900.00', 'thb', '', '2015-01-23 13:07:58', '2015-01-23 13:08:51', 0),
(10, 'ສູດປູນ 45 Mpa', 'm3', '500.00', '670.00', '1120.00', '169.00', '525.00', '3575.00', '0.00', '3100.00', 'thb', '', '2015-01-23 13:08:37', '2015-01-23 13:08:37', 0);

--
-- Triggers `product`
--
DELIMITER //
CREATE TRIGGER `product_BEFORE_INSERT` BEFORE INSERT ON `product`
 FOR EACH ROW BEGIN
SET new.remove=0;
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE IF NOT EXISTS `service` (
`id` int(11) NOT NULL,
  `service_name` varchar(545) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `currency` varchar(5) NOT NULL,
  `unit` varchar(45) NOT NULL,
  `remark` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `remove` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`id`, `service_name`, `price`, `currency`, `unit`, `remark`, `created_at`, `updated_at`, `remove`) VALUES
(1, 'Concret Fomular 1234', '150.00', 'thb', 'm3', '', '2015-01-25 08:58:49', '2015-01-25 08:58:49', 0);

--
-- Triggers `service`
--
DELIMITER //
CREATE TRIGGER `service_BEFORE_INSERT` BEFORE INSERT ON `service`
 FOR EACH ROW BEGIN
SET new.remove=0;
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `transaction_child`
--

CREATE TABLE IF NOT EXISTS `transaction_child` (
`id` int(11) NOT NULL,
  `transaction_parent_id` int(11) NOT NULL,
  `issue_slip_id` varchar(45) DEFAULT NULL,
  `issue_date` date DEFAULT NULL,
  `product_id` int(11) NOT NULL,
  `quality` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `remark` varchar(145) DEFAULT NULL,
  `truck_number` varchar(45) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` varchar(45) DEFAULT NULL,
  `remove` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `transaction_parent`
--

CREATE TABLE IF NOT EXISTS `transaction_parent` (
`id` int(11) NOT NULL,
  `transaction_number` varchar(45) DEFAULT NULL COMMENT 'AA_1001',
  `customer_id` int(11) NOT NULL,
  `exchange_rate_id` int(11) NOT NULL,
  `grand_total` decimal(10,2) DEFAULT '0.00' COMMENT 'Sum value of transaction_child.total',
  `transaction_status` tinyint(5) DEFAULT NULL COMMENT '0 = Pending / Waiting for Approve\n1 = Approved / Print\n2 = Waiting for payment',
  `created_by` int(11) DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `remove` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=304 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `transaction_parent`
--

INSERT INTO `transaction_parent` (`id`, `transaction_number`, `customer_id`, `exchange_rate_id`, `grand_total`, `transaction_status`, `created_by`, `approved_by`, `created_at`, `updated_at`, `remove`) VALUES
(301, 'ITP_301', 1, 4, '0.00', 0, 1, NULL, '2015-01-25 09:55:13', '2015-01-25 09:55:13', 0),
(302, 'BL302', 2, 4, '0.00', 0, 1, NULL, '2015-01-25 10:36:41', '2015-01-25 10:36:41', 0),
(303, 'SKM_303', 3, 4, '0.00', 0, 1, NULL, '2015-01-25 10:42:13', '2015-01-25 10:42:13', 0);

--
-- Triggers `transaction_parent`
--
DELIMITER //
CREATE TRIGGER `transaction_parent_BEFORE_INSERT` BEFORE INSERT ON `transaction_parent`
 FOR EACH ROW BEGIN
SET new.remove = 0;
SET new.transaction_status = 0;
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
`id` int(11) NOT NULL,
  `user_group_id` int(11) NOT NULL,
  `login` varchar(145) NOT NULL,
  `password` varchar(145) NOT NULL,
  `firstname` varchar(145) NOT NULL,
  `lastname` varchar(145) DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `systemUser` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `remove` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `user_group_id`, `login`, `password`, `firstname`, `lastname`, `remember_token`, `systemUser`, `created_at`, `updated_at`, `remove`) VALUES
(1, 1, 'dsouksavatd@gmail.com', '$2y$10$cNiaCpZ5JTq47YKTAJXB4.s8uTza4Jfoqh/0QhFD64F45hqXu.doW', 'Somwang', 'Souksavatd', 'tQDLOVfYKnElaF1oH7BZ8dGWHurFcvdduU4zEG6QYqcecgWBs5weV6dmOpzv', 1, '2015-01-20 00:00:00', '2015-01-25 09:40:09', 0),
(2, 1, 'theppany@gmail.com', '$2y$10$cNiaCpZ5JTq47YKTAJXB4.s8uTza4Jfoqh/0QhFD64F45hqXu.doW', 'Theppany', 'Khanthy', NULL, 1, '2015-01-20 00:00:00', '2015-01-20 00:00:00', 0),
(3, 2, 'demo-manager', '$2y$10$jsyX/g4kYTNqzDBKaDc43.EeQxlJGSazNgsJ.l2eBBJPwJYDm2mWK', 'demo-manager', '', '1agpE2LJKq3hTt8uN09CccJGqgVR8PFsANKE1ojhi5hnXvWMrUVougknCGfI', 0, '2015-01-20 09:26:17', '2015-01-21 16:07:46', 0),
(4, 3, 'demo-acc', '$2y$10$i7K7lJtzlYR0ZQuGTr/E8OZVjZdkpYU24GNyxD3cs/g1sr9ZWOTc2', 'demo-acc', '', NULL, 0, '2015-01-20 09:26:35', '2015-01-20 09:26:35', 0),
(5, 4, 'demo-acc-in', '$2y$10$61nl63xlBBjfsoZNdmYuaOLuzVg6E8k17f6rCLGTTyLXgb.6dEbJ.', 'demo-acc-in', '', NULL, 0, '2015-01-20 09:26:46', '2015-01-20 09:26:46', 0),
(6, 5, 'demo-acc-out', '$2y$10$Uiazkz7WuILatdZy7aN9re.SL5QLTglcrjg6X/hgBBFxztFTxr2nq', 'demo-acc-in', '', NULL, 0, '2015-01-20 09:27:21', '2015-01-20 09:27:21', 0);

--
-- Triggers `user`
--
DELIMITER //
CREATE TRIGGER `user_BEFORE_INSERT` BEFORE INSERT ON `user`
 FOR EACH ROW -- Edit trigger body code below this line. Do not edit lines above this one
BEGIN
SET new.remove = 0;
SET new.systemUser = 0;
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `user_group`
--

CREATE TABLE IF NOT EXISTS `user_group` (
`id` int(11) NOT NULL,
  `name` varchar(145) NOT NULL,
  `permissionList` text,
  `invisible` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_group`
--

INSERT INTO `user_group` (`id`, `name`, `permissionList`, `invisible`, `created_at`, `updated_at`) VALUES
(1, 'Administrator', NULL, 1, NULL, NULL),
(2, 'ຜູ້ອຳນວຍການ', '{"1":"\\u0ec0\\u0e9e\\u0eb5\\u0ec8\\u0ea1\\u0e9c\\u0eb9\\u0ec9\\u0ec3\\u0e8a\\u0ec9\\u0e87\\u0eb2\\u0e99 ( User Add )","2":"\\u0ea5\\u0ebb\\u0e9a\\u0ea5\\u0ec9\\u0eb2\\u0e87 ( User Remove )","3":"\\u0eaa\\u0eb0\\u0ec1\\u0e94\\u0e87\\u0ea5\\u0eb2\\u0e8d\\u0e81\\u0eb2\\u0e99 ( User List )","4":"\\u0ec1\\u0e81\\u0ec9\\u0ec4\\u0e82\\u0ea5\\u0eb0\\u0eab\\u0eb1\\u0e94\\u0e9c\\u0ec8\\u0eb2\\u0e99 ( Change User Password )","5":"\\u0eaa\\u0eb0\\u0ec1\\u0e94\\u0e87\\u0ea5\\u0eb2\\u0e8d\\u0e81\\u0eb2\\u0e99 ( Customer List )","6":"\\u0ec0\\u0e9e\\u0eb5\\u0ec8\\u0ea1\\u0ea5\\u0eb2\\u0e8d\\u0e81\\u0eb2\\u0e99 ( Customer Add )","7":"\\u0ec1\\u0e81\\u0ec9\\u0ec4\\u0e82 ( Customer Edit )","8":"\\u0ea5\\u0ebb\\u0e9a\\u0ea5\\u0ec9\\u0eb2\\u0e87 ( Customer Remove )","11":"\\u0ec1\\u0e81\\u0ec9\\u0ec4\\u0e82\\u0ead\\u0eb1\\u0e94\\u0e95\\u0eb2\\u0ec1\\u0ea5\\u0e81\\u0e9b\\u0ec8\\u0ebd\\u0e99 ( Update Exchange Rate )","12":"\\u0e95\\u0eb1\\u0ec9\\u0e87\\u0e84\\u0ec8\\u0eb2\\u0e97\\u0ebb\\u0ec8\\u0ea7\\u0ec4\\u0e9b ( General Setting )"}', 0, '2015-01-20 00:00:00', '2015-01-21 15:47:52'),
(3, 'ບໍລິຫານ ຜະແນກບັນຊີ', '{"5":"\\u0eaa\\u0eb0\\u0ec1\\u0e94\\u0e87\\u0ea5\\u0eb2\\u0e8d\\u0e81\\u0eb2\\u0e99 ( Customer List )","11":"\\u0ec1\\u0e81\\u0ec9\\u0ec4\\u0e82\\u0ead\\u0eb1\\u0e94\\u0e95\\u0eb2\\u0ec1\\u0ea5\\u0e81\\u0e9b\\u0ec8\\u0ebd\\u0e99 ( Update Exchange Rate )"}', 0, NULL, '2015-01-21 15:48:23'),
(4, 'ພະແນກບັນຊີ - ຂາເຂົ້າ', NULL, 0, NULL, NULL),
(5, 'ພະແນກບັນຊີ - ຂາອອກ', NULL, 0, NULL, NULL);

--
-- Triggers `user_group`
--
DELIMITER //
CREATE TRIGGER `user_group_BINS` BEFORE INSERT ON `user_group`
 FOR EACH ROW -- Edit trigger body code below this line. Do not edit lines above this one
BEGIN
SET new.invisible = 0;
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `user_group_permission`
--

CREATE TABLE IF NOT EXISTS `user_group_permission` (
`id` int(11) NOT NULL,
  `permissionZone` varchar(145) NOT NULL,
  `permissionTitle` varchar(145) NOT NULL,
  `permissionDescription` varchar(245) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_group_permission`
--

INSERT INTO `user_group_permission` (`id`, `permissionZone`, `permissionTitle`, `permissionDescription`) VALUES
(1, 'ການບໍລິຫານຜູ້ໃຊ້ງານ', 'ເພີ່ມຜູ້ໃຊ້ງານ ( User Add )', 'ອະນຸຍາດໃນການເພີ່ມຜູ້ໃຊ້ງານ'),
(2, 'ການບໍລິຫານຜູ້ໃຊ້ງານ', 'ລົບລ້າງ ( User Remove )', 'ອະນຸຍາດໃຫ້ລົບລ້າງຜູ້ໃຊ້ງານ'),
(3, 'ການບໍລິຫານຜູ້ໃຊ້ງານ', 'ສະແດງລາຍການ ( User List )', 'ອະນຸຍາດໃຫ້ສະແດງລາຍການຜູ້ໃຊ້ງານ'),
(4, 'ການບໍລິຫານຜູ້ໃຊ້ງານ', 'ແກ້ໄຂລະຫັດຜ່ານ ( Change User Password )', 'ອະນຸຍາດໃຫ້ແກ້ໄຂລະຫັດຜ່ານຂອງຜູ້ໃຊ້ງານ'),
(5, 'ການບໍລິຫານລາຍການລູກຄ້າ', 'ສະແດງລາຍການ ( Customer List )', 'ອະນຸຍາດໃຫ້ສະແດງລາຍການຂໍ້ມູນລູກຄ້າ'),
(6, 'ການບໍລິຫານລາຍການລູກຄ້າ', 'ເພີ່ມລາຍການ ( Customer Add )', 'ອະນຸຍາດໃຫ້ເພິ້ມລາຍການລູກຄ້າ'),
(7, 'ການບໍລິຫານລາຍການລູກຄ້າ', 'ແກ້ໄຂ ( Customer Edit )', 'ອະນຸຍາດໃຫ້ແກ້ໄຂລາຍການລູກຄ້າ'),
(8, 'ການບໍລິຫານລາຍການລູກຄ້າ', 'ລົບລ້າງ ( Customer Remove )', 'ອະນຸຍາດໃຫ້ລົບລ້າງລາຍການລູກຄ້າ'),
(10, 'ການບໍລິຫານຜູ້ໃຊ້ງານ', 'ກຳໜົດສິດກຸ່ມຜູ້ໃຊ້ງານ ( Set Group Permission )', 'ອະນຸຍາດໃຫ້ກຳໜົດສິດກຸ່ມຜູ້ໃຊ້ງານ'),
(11, 'ຕັ້ງຄ່າ', 'ແກ້ໄຂອັດຕາແລກປ່ຽນ ( Update Exchange Rate )', 'ອະນຸຍາດໃຫ້ແກ້ໄຂອັດຕາແລກປ່ຽນ'),
(12, 'ຕັ້ງຄ່າ', 'ຕັ້ງຄ່າທົ່ວໄປ ( General Setting )', 'ອະນຸຍາດໃຫ້ແກ້ໄຂຄ່າຂໍ້ມູນພື້ນຖານທົ່ວໄປ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `application_log`
--
ALTER TABLE `application_log`
 ADD PRIMARY KEY (`id`), ADD KEY `fk_transaction_log_user1_idx` (`user_id`);

--
-- Indexes for table `company_profile`
--
ALTER TABLE `company_profile`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
 ADD PRIMARY KEY (`id`), ADD KEY `company_name` (`company_name`), ADD KEY `contact_name` (`contact_name`);

--
-- Indexes for table `exchange_rate`
--
ALTER TABLE `exchange_rate`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service`
--
ALTER TABLE `service`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaction_child`
--
ALTER TABLE `transaction_child`
 ADD PRIMARY KEY (`id`), ADD KEY `fk_transaction_child_transaction_parent1_idx` (`transaction_parent_id`), ADD KEY `fk_transaction_child_product1_idx` (`product_id`);

--
-- Indexes for table `transaction_parent`
--
ALTER TABLE `transaction_parent`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
 ADD PRIMARY KEY (`id`), ADD KEY `fk_user_user_group1_idx` (`user_group_id`), ADD KEY `login` (`login`), ADD KEY `password` (`password`);

--
-- Indexes for table `user_group`
--
ALTER TABLE `user_group`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_group_permission`
--
ALTER TABLE `user_group_permission`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `application_log`
--
ALTER TABLE `application_log`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `company_profile`
--
ALTER TABLE `company_profile`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `exchange_rate`
--
ALTER TABLE `exchange_rate`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=400;
--
-- AUTO_INCREMENT for table `service`
--
ALTER TABLE `service`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `transaction_child`
--
ALTER TABLE `transaction_child`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=200;
--
-- AUTO_INCREMENT for table `transaction_parent`
--
ALTER TABLE `transaction_parent`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=304;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `user_group`
--
ALTER TABLE `user_group`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `user_group_permission`
--
ALTER TABLE `user_group_permission`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `application_log`
--
ALTER TABLE `application_log`
ADD CONSTRAINT `fk_transaction_log_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `transaction_child`
--
ALTER TABLE `transaction_child`
ADD CONSTRAINT `fk_transaction_child_product1` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `fk_transaction_child_transaction_parent1` FOREIGN KEY (`transaction_parent_id`) REFERENCES `transaction_parent` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `user`
--
ALTER TABLE `user`
ADD CONSTRAINT `fk_user_user_group1` FOREIGN KEY (`user_group_id`) REFERENCES `user_group` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
